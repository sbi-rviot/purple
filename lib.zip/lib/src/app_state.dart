// lib/src/app_state.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import 'models.dart';
import 'services/asr_service.dart';
import 'services/liquid_service.dart';
import 'services/tts_service.dart';
import 'storage/local_store.dart';
import 'assistant_profiles.dart';

enum Phase { listening, thinking, speaking }

class AppState extends ChangeNotifier {
  // --- Tunables -------------------------------------------------------------
  static const Duration silenceTimeout = Duration(seconds: 2);
  static const Duration kPostTtsIgnore = Duration(milliseconds: 1200);

  // --- Persona / profile ----------------------------------------------------
  final List<AssistantProfile> profiles = kAssistantProfiles;
  AssistantProfile profile = kAssistantProfiles.first;

  String get assistantName => profile.name;
  Color get themeSeedColor => profile.color;
  String get assistantDescription => profile.description;
  String get systemPrompt => profile.systemPrompt;

  void setProfile(AssistantProfile p) {
    if (profile.key == p.key) return;
    profile = p;
    notifyListeners();
  }

  // --- Persistence / UX -----------------------------------------------------
  final xp = XpState();
  final glossary = <String>{};
  final _store = LocalStore();

  // --- I/O services ---------------------------------------------------------
  final _tts = TtsService();
  late final AsrService _asr;
  late final LiquidService _liquid;

  // --- Conversation store ---------------------------------------------------
  final utterances = <Utterance>[];

  // --- Streaming / phases ---------------------------------------------------
  StreamSubscription<AsrResult>? _sub;
  Timer? _silenceTimer;
  String _currentTranscript = "";

  Phase _phase = Phase.listening;
  bool _isProcessing = false;
  DateTime _ignoreAsrUntil = DateTime.fromMillisecondsSinceEpoch(0);

  bool isUp = false;
  bool _ttsActive = false;

  // Reattach control (NEW/ADJUSTED)
  int _attachToken = 0;                 // invalidates stale reattach attempts
  int _attachBackoffMs = 150;           // start small
  static const int _attachBackoffMaxMs = 1200;
  Timer? _reattachTimer;                // cancelable reattach timer
  int _reattachAttempt = 0;             // backoff step index

  // ---------- Lifecycle -----------------------------------------------------
  Future<void> init() async {
    await _store.init();
    xp.totalXp = await _store.loadXp();
    glossary.addAll(await _store.loadGlossary());
    utterances.addAll(await _store.loadUtterances());

    profile = profiles.firstWhere((p) => p.key == 'company', orElse: () => profiles.first);

    _asr = AsrService.impl();
    _liquid = LiquidService();
    await _tts.init();

    print("[AppState] init complete. Ready.");
    notifyListeners();
  }

  void toggleUpDown() {
    final next = !isUp;
    isUp = next;
    if (next) {
      _enterListening();
    } else {
      _stopAll();
    }
    notifyListeners();
  }

  // ---------- Phase helpers -------------------------------------------------
  void _attachAsrIfNeeded({int? token}) {
    // Guard against unintended attach while "down"
    if (!isUp) {
      print("[ASR] attach skipped (isUp=false)");
      return;
    }
    if (_sub != null) return;

    final myToken = token ?? _attachToken;
    print("[ASR] attach (enterListening) token=$myToken");

    _sub = _asr.start().listen(
      _onAsrEvent,
      onError: (e, st) {
        if (myToken != _attachToken) {
          print("[ASR] onError (stale token=$myToken) — ignore");
          return;
        }
        print("[ASR] onError: $e (token=$myToken)");
      },
      onDone: () {
        if (myToken != _attachToken) {
          print("[ASR] onDone (stale token=$myToken) — ignore");
          return;
        }
        _sub = null;
        if (!isUp) {
          print("[ASR] onDone — app is down, not reattaching (token=$myToken)");
          return;
        }

        // Exponential backoff with cap; cancel any previous timer
        _reattachAttempt = (_reattachAttempt + 1).clamp(1, 4);
        final delays = [150, 300, 600, 1200];
        final delayMs = delays[_reattachAttempt - 1];

        _reattachTimer?.cancel();
        _reattachTimer = Timer(Duration(milliseconds: delayMs), () {
          if (!isUp) {
            print("[ASR] reattach canceled: isUp=false (token=$myToken)");
            return;
          }
          if (myToken != _attachToken) {
            print("[ASR] reattach canceled by token (token=$myToken, current=$_attachToken)");
            return;
          }
          print("[ASR] reattach after ${delayMs}ms (token=$myToken)");
          _attachAsrIfNeeded(token: myToken);
        });
      },
    );
  }

  void _enterListening() {
    _phase = Phase.listening;
    _isProcessing = false;
    _silenceTimer?.cancel();
    _silenceTimer = null;
    _currentTranscript = "";

    // Reset reattach state for a fresh session
    _attachBackoffMs = 150;
    _reattachAttempt = 0;
    _reattachTimer?.cancel();
    _reattachTimer = null;

    _attachAsrIfNeeded(token: _attachToken);

    if (DateTime.now().isBefore(_ignoreAsrUntil)) {
      print("[Phase] → LISTENING (ASR on) — stream running, ignore until ${_ignoreAsrUntil.toIso8601String()}");
    } else {
      print("[Phase] → LISTENING (ASR on) — stream running");
    }
  }

  Future<void> _enterThinking(String transcript, AsrResult asr) async {
    if (_isProcessing) return;
    _isProcessing = true;
    _phase = Phase.thinking;

    _silenceTimer?.cancel();
    _silenceTimer = null;

    // IMPORTANT: Do NOT stop/cancel ASR. We keep the stream alive.
    print("[Phase] → THINKING | text=\"${_truncate(transcript, 120)}\"");

    final conversationSummary = _summarizeConversation();
    final prompt = systemPrompt;

    try {
      final reply = await _liquid.generateReply(
        "$prompt\n\nContext summary:\n$conversationSummary",
        transcript,
      );

      utterances.insert(
        0,
        Utterance(
          id: const Uuid().v4(),
          createdAt: DateTime.now(),
          audioPath: asr.audioPath,
          rawText: transcript,
          improvedText: transcript,
          lowConfidence: asr.lowConfidenceWords,
          needsReview: asr.needsReview,
          responseText: reply,
        ),
      );
      await _store.saveUtterances(utterances);
      notifyListeners();

      await _enterSpeaking(reply);
    } catch (e, st) {
      print("[AppState] Liquid error: $e\n$st");
      _isProcessing = false;
      if (isUp) _enterListening();
    }
  }

  Future<void> _enterSpeaking(String reply) async {
    _phase = Phase.speaking;

    // Keep ASR stream attached; just ignore via gate.
    _silenceTimer?.cancel();
    _silenceTimer = null;

    _ttsActive = true;

    print("[Phase] → SPEAKING | reply=${reply.length} chars");
    await _tts.speak(reply);

    // After speech ends: brief ignore window to swallow echo
    _ignoreAsrUntil = DateTime.now().add(kPostTtsIgnore);

    _ttsActive = false;

    _isProcessing = false;
    _currentTranscript = "";
    print("[Phase] SPEAKING done — will re-enter LISTENING after ${kPostTtsIgnore.inMilliseconds}ms");
    if (isUp) _enterListening();
  }

  Future<void> _stopAll() async {
    // Make the app "down" so onDone won't reattach.
    isUp = false;

    _phase = Phase.listening;
    _isProcessing = false;

    _silenceTimer?.cancel();
    _silenceTimer = null;

    // Invalidate any pending reattach scheduled with an older token
    _attachToken++;

    // Cancel pending reattach timers/backoff attempts
    _reattachTimer?.cancel();
    _reattachTimer = null;
    _reattachAttempt = 0;

    // Tear down ASR cleanly
    await _sub?.cancel();
    _sub = null;
    await _asr.stop();

    // Stop TTS
    await _tts.stop();

    print("[AppState] Stopped (ASR detached, TTS stopped, timers cleared)");
  }

  // ---------- ASR handling --------------------------------------------------
  void _onAsrEvent(AsrResult asr) {
    final now = DateTime.now();

    // Swallow ALL ASR while TTS is active OR while the post-TTS ignore window is alive.
    if (_ttsActive || now.isBefore(_ignoreAsrUntil)) {
      _currentTranscript = asr.text;
      return;
    }

    if (_phase != Phase.listening) return;

    // Always buffer latest
    _currentTranscript = asr.text;

    // FINAL gets priority — schedule send immediately
    if (asr.isFinal) {
      _silenceTimer?.cancel();
      print("[ASR] FINAL '${_truncate(asr.text, 80)}' — schedule SEND in 0ms");
      _silenceTimer = Timer(Duration.zero, () {
        if (_phase != Phase.listening || _isProcessing) return;
        final toSend = _currentTranscript.trim();
        if (toSend.isEmpty) return;
        _ignoreAsrUntil = DateTime.fromMillisecondsSinceEpoch(0);
        print("[Timer] FINAL → send: \"${_truncate(toSend, 120)}\"");
        unawaited(_enterThinking(toSend, asr));
      });
      return;
    }

    // Non-final chunk: arm/reset silence timer
    _silenceTimer?.cancel();
    print("[ASR] '${_truncate(asr.text, 80)}' (final=${asr.isFinal}) — arm SilenceTimer=${silenceTimeout.inMilliseconds}ms");

    _silenceTimer = Timer(silenceTimeout, () {
      if (_phase != Phase.listening) return;
      if (_isProcessing) return;
      final toSend = _currentTranscript.trim();
      if (toSend.isEmpty) return;
      _ignoreAsrUntil = DateTime.fromMillisecondsSinceEpoch(0);
      print("[Timer] SilenceTimer FIRE → send: \"${_truncate(toSend, 120)}\"");
      unawaited(_enterThinking(toSend, asr));
    });
  }

  // ---------- Review actions ------------------------------------------------
  Future<void> approve(Utterance u) async {
    u.needsReview = false;
    xp.add(10);
    await _store.saveXp(xp.totalXp);
    await _store.saveUtterances(utterances);
    notifyListeners();
  }

  Future<void> editAndSave(Utterance u, String corrected) async {
    final before = u.improvedText;
    u.improvedText = corrected;
    u.needsReview = false;
    xp.add(15);
    await _store.addCorrection(CorrectionPair(before: before, after: corrected));
    await _store.saveXp(xp.totalXp);
    await _store.saveUtterances(utterances);
    notifyListeners();
  }

  Future<void> addToGlossary(String term) async {
    glossary.add(term);
    xp.add(5);
    await _store.saveGlossary(glossary);
    await _store.saveXp(xp.totalXp);
    notifyListeners();
  }

  Level get level => xp.level;

  // ---------- Summarization -------------------------------------------------
  String _summarizeConversation() {
    if (utterances.isEmpty) return "";
    final buffer = StringBuffer();
    for (final u in utterances.take(5).toList().reversed) {
      buffer.writeln("User: ${u.improvedText}");
      buffer.writeln("Assistant: ${u.responseText}");
    }
    return buffer.toString();
  }

  // ---------- Utils ---------------------------------------------------------
  String _truncate(String s, int max) =>
      s.length <= max ? s : s.substring(0, max) + "…";
}

// Fire-and-forget helper
void unawaited(Future<void>? f) {}
