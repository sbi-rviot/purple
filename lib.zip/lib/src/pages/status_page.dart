// lib/src/pages/status_page.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../assistant_profiles.dart';
import '../models.dart';

class StatusPage extends StatelessWidget {
  const StatusPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: const _TitleWithProfilePicker(),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Assistant'),
              Tab(text: 'Review'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _AssistantTab(),
            _ReviewTab(),
          ],
        ),
      ),
    );
  }
}

class _TitleWithProfilePicker extends StatelessWidget {
  const _TitleWithProfilePicker();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Row(
      children: [
        const SizedBox(width: 8),
        CircleAvatar(
          radius: 16,
          backgroundColor: app.themeSeedColor.withOpacity(0.15),
          child: Text(
            app.assistantName.characters.isNotEmpty
                ? app.assistantName.characters.first
                : '?',
            style: TextStyle(
              color: app.themeSeedColor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(width: 12),
        PopupMenuButton<AssistantProfile>(
          onSelected: (p) => context.read<AppState>().setProfile(p),
          itemBuilder: (context) => app.profiles
              .map(
                (p) => PopupMenuItem(
                  value: p,
                  child: Row(
                    children: [
                      CircleAvatar(radius: 8, backgroundColor: p.color),
                      const SizedBox(width: 8),
                      Text(p.name),
                    ],
                  ),
                ),
              )
              .toList(),
          child: Row(
            children: [
              Text(
                app.assistantName,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.arrow_drop_down),
            ],
          ),
        ),
      ],
    );
  }
}

class _AssistantTab extends StatelessWidget {
  const _AssistantTab();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Align(
      alignment: Alignment.topCenter,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const [
              _FaceHero(),
              SizedBox(height: 16),
              _XpPill(),
              SizedBox(height: 16),
              _PersonaDescription(),
              SizedBox(height: 20),
              _Controls(),
            ],
          ),
        ),
      ),
    );
  }
}

class _FaceHero extends StatelessWidget {
  const _FaceHero();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final seed = app.themeSeedColor;
    final letter = app.assistantName.characters.isNotEmpty
        ? app.assistantName.characters.first
        : '?';

    // Simple progress to next level (placeholder: 0..1 using XP % 100)
    final rawXp = app.xp.totalXp;
    final progress = ((rawXp % 100) / 100).clamp(0.0, 1.0);

    const double size = 120;
    const double ringStroke = 8;

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Background ring (track)
          SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              value: 1,
              strokeWidth: ringStroke,
              valueColor: AlwaysStoppedAnimation<Color>(
                seed.withOpacity(0.12),
              ),
            ),
          ),
          // Progress ring
          SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: ringStroke,
              valueColor: AlwaysStoppedAnimation<Color>(seed),
              backgroundColor: Colors.transparent,
            ),
          ),
          // Avatar
          Container(
            width: size - 24,
            height: size - 24,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [seed.withOpacity(0.25), seed],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              letter,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 44,
                color: Colors.white,
              ),
            ),
          ),
          // Little "XP" dot at the end of the ring
          _XpDot(progress: progress, color: seed, radius: (size / 2) - (ringStroke / 2)),
        ],
      ),
    );
  }
}

class _XpDot extends StatelessWidget {
  final double progress; // 0..1
  final Color color;
  final double radius;

  const _XpDot({
    required this.progress,
    required this.color,
    required this.radius,
  });

  @override
  Widget build(BuildContext context) {
    // Convert progress → angle (start at top, clockwise)
    final angle = -math.pi / 2 + progress * 2 * math.pi;
    final dx = radius * math.cos(angle);
    final dy = radius * math.sin(angle);

    return Transform.translate(
      offset: Offset(dx, dy),
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.35),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        alignment: Alignment.center,
        child: const Text(
          'XP',
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _PersonaDescription extends StatelessWidget {
  const _PersonaDescription();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final theme = Theme.of(context);
    return Text(
      app.assistantDescription,
      textAlign: TextAlign.center,
      style: theme.textTheme.bodyMedium,
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final seed = app.themeSeedColor;

    if (!app.isUp) {
      // START
      return SizedBox(
        width: double.infinity,
        height: 46,
        child: FilledButton.icon(
          onPressed: () => context.read<AppState>().toggleUpDown(),
          icon: const Icon(Icons.play_arrow),
          label: const Text('Start'),
          style: FilledButton.styleFrom(
            backgroundColor: seed,
            foregroundColor: Colors.white,
          ),
        ),
      );
    }

    // PAUSE + STOP (when running)
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 46,
          child: FilledButton.icon(
            onPressed: () {
              // Pause: just toggle listening, keep history
              context.read<AppState>().toggleUpDown();
            },
            icon: const Icon(Icons.pause),
            label: const Text('Pause'),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 46,
          child: FilledButton.icon(
            onPressed: () {
              // Stop: toggle off if needed AND clear the thread
              final a = context.read<AppState>();
              if (a.isUp) {
                a.toggleUpDown();
              }
              a.utterances.clear();
              a.notifyListeners();
            },
            icon: const Icon(Icons.stop),
            label: const Text('Stop'),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}

class _XpPill extends StatelessWidget {
  const _XpPill();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final lvl = app.level.name.toUpperCase();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        'XP: ${app.xp.totalXp} • $lvl',
        style: const TextStyle(fontWeight: FontWeight.w600),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _ReviewTab extends StatelessWidget {
  const _ReviewTab();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final needs = app.utterances.where((u) => u.needsReview).toList();

    if (needs.isEmpty) {
      return const Center(child: Text('Nothing to review right now.'));
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      itemCount: needs.length,
      itemBuilder: (context, i) {
        return _UtteranceCard(u: needs[i]);
      },
    );
  }
}

class _UtteranceCard extends StatelessWidget {
  final Utterance u;
  const _UtteranceCard({required this.u});

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // timestamp
            Text(
              u.createdAt.toLocal().toString().split('.').first,
              style: theme.textTheme.labelSmall,
            ),
            const SizedBox(height: 8),

            if (u.rawText.isNotEmpty) ...[
              const Text('Heard', style: TextStyle(fontWeight: FontWeight.w700)),
              Text(u.rawText),
              const SizedBox(height: 8),
            ],
            if (u.improvedText.isNotEmpty) ...[
              const Text('Improved', style: TextStyle(fontWeight: FontWeight.w700)),
              Text(u.improvedText),
              const SizedBox(height: 8),
            ],

            const Text('Response', style: TextStyle(fontWeight: FontWeight.w700)),
            Text(u.responseText),

            const SizedBox(height: 12),

            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (u.needsReview)
                  FilledButton.tonal(
                    onPressed: () => app.approve(u),
                    child: const Text('Approve'),
                  ),
                FilledButton.tonal(
                  onPressed: () async {
                    final text = await _promptForText(
                      context,
                      title: 'Edit transcript',
                      initial: u.improvedText,
                    );
                    if (text != null && text.trim().isNotEmpty) {
                      await app.editAndSave(u, text.trim());
                    }
                  },
                  child: const Text('Edit'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () async {
                    final term = await _promptForText(
                      context,
                      title: 'Add to glossary',
                      hint: 'Term or phrase',
                    );
                    if (term != null && term.trim().isNotEmpty) {
                      await app.addToGlossary(term.trim());
                    }
                  },
                  icon: const Icon(Icons.add),
                  label: const Text('Glossary'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

Future<String?> _promptForText(
  BuildContext context, {
  required String title,
  String? initial,
  String? hint,
}) async {
  final controller = TextEditingController(text: initial ?? '');
  return showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: controller,
        minLines: 1,
        maxLines: 5,
        decoration: InputDecoration(hintText: hint),
        autofocus: true,
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(context, controller.text),
          child: const Text('Save'),
        ),
      ],
    ),
  );
}
